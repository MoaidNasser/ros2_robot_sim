#!/usr/bin/env python3
"""
Ultrasonic Detour Supervisor (v3.1 - corner trigger + early forward-pass exit)

Based on v3:
- Keeps v3 fixes: detour-side exit logic + yaw cap + adaptive wall steering.
Adds two small improvements:
1) Corner-trigger: during NAVIGATING, trigger avoidance if a corner obstacle is detected
   by left/right sensors even when front doesn't see it.
2) Early exit in forward pass: if we moved a small minimum distance and the obstacle-side
   becomes clearly safe (stable), exit forward pass early (prevents overshoot).

Nav2 -> /cmd_vel_nav -> supervisor -> /cmd_vel
Sensors: /us/front_*, /us/left_*, /us/right_* (Range)
Odom: /odom
"""

from std_msgs.msg import Bool
import time

import math
from enum import Enum
from dataclasses import dataclass

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSDurabilityPolicy, QoSHistoryPolicy

from geometry_msgs.msg import PoseStamped, Twist
from sensor_msgs.msg import Range
from nav_msgs.msg import Odometry
from nav2_msgs.action import NavigateToPose


class Side(Enum):
    LEFT = 1
    RIGHT = -1


class Mode(Enum):
    IDLE = 0
    NAVIGATING = 1
    AVOID_START = 2
    AVOID_ARC = 3
    AVOID_BACKUP = 4
    AVOID_FORWARD_PASS = 5
    RESUME_GOAL = 6


@dataclass
class FilteredRange:
    value: float
    stamp_sec: float


def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


def quat_to_yaw(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def ang_wrap(a):
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


class UltrasonicDetourSupervisor(Node):
    def __init__(self):
        super().__init__('ultrasonic_detour_supervisor')

        # -------------------------
        # Params
        # -------------------------
        self.declare_parameter('control_rate_hz', 20.0)

        self.declare_parameter('robot_radius_m', 0.20)
        self.declare_parameter('safety_margin_m', 0.10)

        # Trigger distances
        self.declare_parameter('avoid_extra_m', 0.25)  # D_avoid = D_stop + avoid_extra

        # NEW: corner-trigger params
        # D_corner = D_stop + corner_extra_m
        self.declare_parameter('corner_extra_m', 0.05)
        self.declare_parameter('corner_v_min', 0.03)  # only consider corner trigger if moving forward faster than this

        # Exit criteria (IMPORTANT)
        self.declare_parameter('clear_front_m', 0.90)      # front must be this clear
        self.declare_parameter('detour_clear_m', 0.80)     # detour side must be this clear
        self.declare_parameter('obstacle_min_m', 0.38)     # obstacle side only needs to be above "safe min"

        # Hysteresis
        self.declare_parameter('persistence_ms', 250)
        self.declare_parameter('stable_ms', 400)
        self.declare_parameter('cool_down_sec', 1.2)

        # Sensor filtering
        self.declare_parameter('ema_alpha', 0.45)
        self.declare_parameter('sensor_timeout_sec', 0.6)
        self.declare_parameter('default_max_range', 4.0)

        # Arc motion
        self.declare_parameter('v_max_detour', 0.12)
        self.declare_parameter('w_min', 0.20)
        self.declare_parameter('w_max', 0.70)
        self.declare_parameter('k_corr', 0.12)
        self.declare_parameter('detour_max_time_sec', 8.0)

        # Anti-over-rotation
        self.declare_parameter('max_arc_yaw_deg', 75.0)     # cap total yaw change during ARC

        # Forward pass distance-based
        self.declare_parameter('commit_distance_m', 1.10)
        self.declare_parameter('v_pass', 0.12)

        # Forward pass steering (adaptive)
        self.declare_parameter('wall_target_m', 0.55)       # keep obstacle-side around/above this
        self.declare_parameter('k_wall_pass', 1.2)          # steering gain away from obstacle-side
        self.declare_parameter('w_pass_max', 0.35)          # max pass yaw rate

        # NEW: early exit in forward pass
        self.declare_parameter('pass_min_distance_m', 0.30)     # must move at least this much before early exit
        self.declare_parameter('pass_clear_margin_m', 0.10)     # early-clear requires dObs > wall_target + margin
        self.declare_parameter('pass_clear_stable_ms', 200)     # early-clear must be stable for this long

        # Backup
        self.declare_parameter('backup_duration_sec', 0.6)
        self.declare_parameter('v_backup', 0.10)

        # Rate limits
        self.declare_parameter('v_rate_limit', 0.60)
        self.declare_parameter('w_rate_limit', 2.20)

        # NAVIGATING side nudge (optional)
        self.declare_parameter('side_nudge_enable', True)
        self.declare_parameter('side_warn_m', 0.55)
        self.declare_parameter('side_nudge_gain', 0.30)
        self.declare_parameter('side_slow_min', 0.40)

        # Topics
        self.declare_parameter('goal_topic', '/goal_pose')
        self.declare_parameter('nav_cmd_topic', '/cmd_vel_nav')
        self.declare_parameter('cmd_out_topic', '/cmd_vel')
        self.declare_parameter('odom_topic', '/odom')

        # ---------- CLIFF (IR) params ----------
        self.declare_parameter("cliff_brake_s", 0.25)        # like safety brake :contentReference[oaicite:3]{index=3}
        self.declare_parameter("cliff_reverse_s", 3)
        self.declare_parameter("cliff_rotate_s", 1.2)
        self.declare_parameter("cliff_reverse_v", 0.12)      # m/s (will be applied as -v)
        self.declare_parameter("cliff_rotate_w", 0.9)        # rad/s
        self.declare_parameter("cliff_clear_stable_s", 0.25) # require stable ground before exit

        self.cliff_brake_s = float(self.get_parameter("cliff_brake_s").value)
        self.cliff_reverse_s = float(self.get_parameter("cliff_reverse_s").value)
        self.cliff_rotate_s = float(self.get_parameter("cliff_rotate_s").value)
        self.cliff_reverse_v = float(self.get_parameter("cliff_reverse_v").value)
        self.cliff_rotate_w = float(self.get_parameter("cliff_rotate_w").value)
        self.cliff_clear_stable_s = float(self.get_parameter("cliff_clear_stable_s").value)

        # Latest IR states (True=ground OK, False=cliff)
        self.ir = {"front": True, "left": True, "right": True, "rear": True}

        # Cliff FSM
        self.cliff_state = "NONE"  # NONE, CLIFF_BRAKE, CLIFF_ESCAPE
        self.cliff_t0 = 0.0
        self.cliff_trigger = None  # which sensor triggered
        self.cliff_turn_sign = 1.0 # +1 left, -1 right
        self.cliff_clear_t0 = None

        # -------------------------
        # Read params
        # -------------------------
        self.rate_hz = float(self.get_parameter('control_rate_hz').value)

        self.robot_radius = float(self.get_parameter('robot_radius_m').value)
        self.safety_margin = float(self.get_parameter('safety_margin_m').value)
        self.avoid_extra = float(self.get_parameter('avoid_extra_m').value)

        self.corner_extra = float(self.get_parameter('corner_extra_m').value)
        self.corner_v_min = float(self.get_parameter('corner_v_min').value)

        self.clear_front = float(self.get_parameter('clear_front_m').value)
        self.detour_clear = float(self.get_parameter('detour_clear_m').value)
        self.obstacle_min = float(self.get_parameter('obstacle_min_m').value)

        self.persistence = float(self.get_parameter('persistence_ms').value) / 1000.0
        self.stable_time = float(self.get_parameter('stable_ms').value) / 1000.0
        self.cool_down_sec = float(self.get_parameter('cool_down_sec').value)

        self.alpha = clamp(float(self.get_parameter('ema_alpha').value), 0.0, 1.0)
        self.sensor_timeout = float(self.get_parameter('sensor_timeout_sec').value)
        self.default_max_range = float(self.get_parameter('default_max_range').value)

        self.v_max_detour = float(self.get_parameter('v_max_detour').value)
        self.w_min = float(self.get_parameter('w_min').value)
        self.w_max = float(self.get_parameter('w_max').value)
        self.k_corr = float(self.get_parameter('k_corr').value)
        self.detour_max_time = float(self.get_parameter('detour_max_time_sec').value)

        self.max_arc_yaw = math.radians(float(self.get_parameter('max_arc_yaw_deg').value))

        self.commit_distance = float(self.get_parameter('commit_distance_m').value)
        self.v_pass = float(self.get_parameter('v_pass').value)

        self.wall_target = float(self.get_parameter('wall_target_m').value)
        self.k_wall_pass = float(self.get_parameter('k_wall_pass').value)
        self.w_pass_max = float(self.get_parameter('w_pass_max').value)

        self.pass_min_distance = float(self.get_parameter('pass_min_distance_m').value)
        self.pass_clear_margin = float(self.get_parameter('pass_clear_margin_m').value)
        self.pass_clear_stable = float(self.get_parameter('pass_clear_stable_ms').value) / 1000.0

        self.backup_duration = float(self.get_parameter('backup_duration_sec').value)
        self.v_backup = float(self.get_parameter('v_backup').value)

        self.v_rate_limit = float(self.get_parameter('v_rate_limit').value)
        self.w_rate_limit = float(self.get_parameter('w_rate_limit').value)

        self.side_nudge_enable = bool(self.get_parameter('side_nudge_enable').value)
        self.side_warn = float(self.get_parameter('side_warn_m').value)
        self.side_nudge_gain = float(self.get_parameter('side_nudge_gain').value)
        self.side_slow_min = float(self.get_parameter('side_slow_min').value)

        self.goal_topic = str(self.get_parameter('goal_topic').value)
        self.nav_cmd_topic = str(self.get_parameter('nav_cmd_topic').value)
        self.cmd_out_topic = str(self.get_parameter('cmd_out_topic').value)
        self.odom_topic = str(self.get_parameter('odom_topic').value)

        # Derived
        self.D_stop = self.robot_radius + self.safety_margin
        self.D_avoid = self.D_stop + self.avoid_extra
        self.D_corner = self.D_stop + self.corner_extra

        # -------------------------
        # QoS
        # -------------------------
        self.sensor_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.VOLATILE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.cmd_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.VOLATILE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10
        )

        # -------------------------
        # State
        # -------------------------
        self.mode = Mode.IDLE
        self.original_goal = None
        self.nav_goal_handle = None

        self.nav_cmd = Twist()
        self.last_nav_cmd_time = 0.0

        self.obstacle_side = Side.LEFT
        self.detour_side = Side.RIGHT

        self.obstacle_seen_since = None
        self.clear_seen_since = None

        self.avoid_started_at = 0.0
        self.backup_end_at = 0.0
        self.cooldown_until = 0.0

        # odom tracking
        self.odom_ready = False
        self.odom_x = 0.0
        self.odom_y = 0.0
        self.odom_yaw = 0.0

        self.pass_start_x = 0.0
        self.pass_start_y = 0.0

        # NEW: early-exit timer during forward pass
        self.pass_clear_seen_since = None

        # yaw cap for arc
        self.arc_yaw0 = 0.0

        # cmd smoothing
        self.last_cmd_v = 0.0
        self.last_cmd_w = 0.0

        self._last_status_log = 0.0
        self._rx_counter = 0

        self.ranges = {
            'front_up': None,
            'front_down': None,
            'left_up': None,
            'left_down': None,
            'right_up': None,
            'right_down': None,
        }

        # -------------------------
        # ROS interfaces
        # -------------------------
        self.nav_client = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        self.create_subscription(PoseStamped, self.goal_topic, self.goal_callback, 10)
        self.create_subscription(Twist, self.nav_cmd_topic, self.nav_cmd_callback, self.cmd_qos)
        self.create_subscription(Odometry, self.odom_topic, self.odom_callback, 20)
        self.create_subscription(Bool, "/ir/front", lambda m: self._ir_cb("front", m), 10)
        self.create_subscription(Bool, "/ir/left",  lambda m: self._ir_cb("left",  m), 10)
        self.create_subscription(Bool, "/ir/right", lambda m: self._ir_cb("right", m), 10)
        self.create_subscription(Bool, "/ir/rear",  lambda m: self._ir_cb("rear",  m), 10)

        for key in self.ranges.keys():
            self.create_subscription(
                Range, f'/us/{key}',
                lambda msg, k=key: self.range_callback(msg, k),
                self.sensor_qos
            )

        self.cmd_pub = self.create_publisher(Twist, self.cmd_out_topic, 10)

        dt = 1.0 / max(1.0, self.rate_hz)
        self.timer = self.create_timer(dt, self.control_loop)

        self.get_logger().info(
            f"Supervisor v3.1: D_stop={self.D_stop:.2f}, D_avoid={self.D_avoid:.2f}, D_corner={self.D_corner:.2f}, "
            f"clear_front={self.clear_front:.2f}, detour_clear={self.detour_clear:.2f}, obstacle_min={self.obstacle_min:.2f}, "
            f"max_arc_yaw={math.degrees(self.max_arc_yaw):.0f}deg, commit={self.commit_distance:.2f}, "
            f"pass_min={self.pass_min_distance:.2f}, pass_clear_thr={(self.wall_target + self.pass_clear_margin):.2f}"
        )

    # ---------- Basic helpers ----------
    def now_sec(self) -> float:
        return self.get_clock().now().nanoseconds / 1e9

    def odom_callback(self, msg: Odometry):
        self.odom_x = msg.pose.pose.position.x
        self.odom_y = msg.pose.pose.position.y
        self.odom_yaw = quat_to_yaw(msg.pose.pose.orientation)
        self.odom_ready = True

    def publish_cmd(self, v: float, w: float, dt: float):
        dv = clamp(v - self.last_cmd_v, -self.v_rate_limit * dt, self.v_rate_limit * dt)
        dw = clamp(w - self.last_cmd_w, -self.w_rate_limit * dt, self.w_rate_limit * dt)
        self.last_cmd_v += dv
        self.last_cmd_w += dw

        cmd = Twist()
        cmd.linear.x = self.last_cmd_v
        cmd.angular.z = self.last_cmd_w
        self.cmd_pub.publish(cmd)

    def stop_robot(self):
        self.last_cmd_v = 0.0
        self.last_cmd_w = 0.0
        self.cmd_pub.publish(Twist())

    #for ir's 
    def _ir_cb(self, name: str, msg: Bool):
        self.ir[name] = bool(msg.data)

    def _cliff_active(self) -> bool:
        # cliff if ANY sensor reports no ground
        return not (self.ir["front"] and self.ir["left"] and self.ir["right"] and self.ir["rear"])

    def _pick_cliff_trigger_and_turn(self):
        # Choose trigger priority (front > left/right > rear)
        if not self.ir["front"]:
            self.cliff_trigger = "front"
            # turn away from the side that is unsafe; if both safe, default left
            if not self.ir["left"] and self.ir["right"]:
                self.cliff_turn_sign = -1.0
            elif not self.ir["right"] and self.ir["left"]:
                self.cliff_turn_sign = 1.0
            else:
                # both sides appear OK, pick the more open side if you want (simple default):
                self.cliff_turn_sign = 1.0
        elif not self.ir["left"]:
            self.cliff_trigger = "left"
            self.cliff_turn_sign = -1.0  # rotate right
        elif not self.ir["right"]:
            self.cliff_trigger = "right"
            self.cliff_turn_sign = 1.0   # rotate left
        else:
            self.cliff_trigger = "rear"
            # rear cliff: rotate (either direction), and don't reverse into it
            self.cliff_turn_sign = 1.0


    # ---------- Sensors ----------
    def range_callback(self, msg: Range, key: str):
        now = self.now_sec()
        r = msg.range
        if not math.isfinite(r):
            return
        r = clamp(r, msg.min_range, msg.max_range)

        prev = self.ranges.get(key)
        if prev is None:
            self.ranges[key] = FilteredRange(value=r, stamp_sec=now)
        else:
            filt = self.alpha * r + (1.0 - self.alpha) * prev.value
            self.ranges[key] = FilteredRange(value=filt, stamp_sec=now)

        self._rx_counter += 1

    def get_dir_dists(self):
        now = self.now_sec()

        def v(name: str):
            fr = self.ranges.get(name)
            if fr is None:
                return self.default_max_range
            if (now - fr.stamp_sec) > self.sensor_timeout:
                return self.default_max_range
            return clamp(fr.value, 0.02, self.default_max_range)

        dF = min(v('front_up'), v('front_down'))
        dL = min(v('left_up'), v('left_down'))
        dR = min(v('right_up'), v('right_down'))
        return dF, dL, dR

    def decide_sides_at_trigger(self, dL: float, dR: float):
        self.obstacle_side = Side.LEFT if dL < dR else Side.RIGHT
        self.detour_side = Side.RIGHT if self.obstacle_side == Side.LEFT else Side.LEFT

    # ---------- Nav2 ----------
    def nav_cmd_callback(self, msg: Twist):
        self.nav_cmd = msg
        self.last_nav_cmd_time = self.now_sec()

    def goal_callback(self, msg: PoseStamped):
        self.original_goal = msg
        self.get_logger().info(
            f"New goal: ({msg.pose.position.x:.2f}, {msg.pose.position.y:.2f}) frame={msg.header.frame_id}"
        )
        self.obstacle_seen_since = None
        self.clear_seen_since = None
        self.cooldown_until = self.now_sec() + self.cool_down_sec

        self.cancel_nav_goal()
        self.send_nav_goal(msg)
        self.mode = Mode.NAVIGATING

    def send_nav_goal(self, goal_pose: PoseStamped):
        if not self.nav_client.wait_for_server(timeout_sec=2.0):
            self.get_logger().error("NavigateToPose server not available!")
            self.mode = Mode.IDLE
            return
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose
        future = self.nav_client.send_goal_async(goal_msg)
        future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn("Nav2 rejected goal.")
            self.mode = Mode.IDLE
            return
        self.nav_goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.goal_result_callback)
        self.get_logger().info("Nav2 goal accepted.")

    def goal_result_callback(self, future):
        status = future.result().status
        if status == 4 and self.mode == Mode.NAVIGATING:
            self.get_logger().info("✓ Goal reached.")
            self.mode = Mode.IDLE
            self.original_goal = None

    def cancel_nav_goal(self):
        if self.nav_goal_handle is not None:
            try:
                self.nav_goal_handle.cancel_goal_async()
            except Exception:
                pass
            self.nav_goal_handle = None

    # ---------- Control helpers ----------
    def nav_side_nudge(self, v_in: float, w_in: float, dL: float, dR: float):
        if not self.side_nudge_enable:
            return v_in, w_in

        dMin = min(dL, dR)
        if dMin >= self.side_warn:
            return v_in, w_in

        u = clamp((self.side_warn - dMin) / max(1e-3, (self.side_warn - self.D_stop)), 0.0, 1.0)

        scale = max(self.side_slow_min, 1.0 - 0.65 * u)
        v_out = v_in * scale

        if dL < dR:
            w_out = w_in - self.side_nudge_gain * u  # obstacle left -> turn right
        else:
            w_out = w_in + self.side_nudge_gain * u  # obstacle right -> turn left

        return v_out, w_out

    def compute_arc_cmd(self, dF: float, dL: float, dR: float):
        denom = max(1e-3, (self.D_avoid - self.D_stop))
        uF = clamp((self.D_avoid - dF) / denom, 0.0, 1.0)

        # slow down when close
        v = self.v_max_detour * (1.0 - 0.80 * uF)

        dObs = dL if self.obstacle_side == Side.LEFT else dR
        if dF <= self.D_stop or dObs <= self.D_stop:
            v = 0.0

        sign = self.detour_side.value
        w_base = sign * (self.w_min + (self.w_max - self.w_min) * uF)

        # gentle centering
        w_corr = self.k_corr * ((1.0 / max(dR, 0.10)) - (1.0 / max(dL, 0.10)))
        w = w_base + w_corr

        # enforce direction
        if self.detour_side == Side.LEFT:
            w = max(w, 0.08)
        else:
            w = min(w, -0.08)

        return v, w

    def should_exit_arc(self, dF, dL, dR):
        dObs = dL if self.obstacle_side == Side.LEFT else dR
        dDet = dR if self.detour_side == Side.RIGHT else dL
        return (dF > self.clear_front) and (dDet > self.detour_clear) and (dObs > self.obstacle_min)

    def start_forward_pass(self):
        if not self.odom_ready:
            self.get_logger().warn("No odom yet -> RESUME_GOAL directly")
            self.mode = Mode.RESUME_GOAL
            return

        self.pass_start_x = self.odom_x
        self.pass_start_y = self.odom_y
        self.pass_clear_seen_since = None  # NEW
        self.mode = Mode.AVOID_FORWARD_PASS
        self.get_logger().info("Clear stable -> FORWARD_PASS")

    def forward_pass_cmd(self, dL, dR):
        dObs = dL if self.obstacle_side == Side.LEFT else dR
        sign = self.detour_side.value

        err = self.wall_target - dObs  # positive => too close
        if err <= 0.0:
            w = 0.0
        else:
            w = sign * clamp(self.k_wall_pass * (err / max(self.wall_target, 1e-3)), 0.0, self.w_pass_max)

        return self.v_pass, w

    # ---------- Main loop ----------
    def control_loop(self):
        now = self.now_sec()
        dt = 1.0 / max(1.0, self.rate_hz)

        dF, dL, dR = self.get_dir_dists()

        if self._cliff_active() or self.cliff_state != "NONE":
            self._handle_cliff(dt)
            return

        if (now - self._last_status_log) > 1.0:
            self._last_status_log = now
            self.get_logger().info(
                f"mode={self.mode.name} dF={dF:.2f} dL={dL:.2f} dR={dR:.2f} "
                f"obs={self.obstacle_side.name} detour={self.detour_side.name} rx={self._rx_counter}"
            )

        if self.mode == Mode.IDLE:
            self.stop_robot()
            return

        if self.mode == Mode.NAVIGATING:
            # Compute current nav cmd (needed for corner-trigger condition)
            if (now - self.last_nav_cmd_time) > 0.5:
                v_cmd_raw, w_cmd_raw = 0.0, 0.0
            else:
                v_cmd_raw, w_cmd_raw = self.nav_cmd.linear.x, self.nav_cmd.angular.z

            # NEW: trigger condition includes corner obstacles
            front_blocked = (dF < self.D_avoid)
            corner_blocked = (v_cmd_raw > self.corner_v_min) and (min(dL, dR) < self.D_corner)
            blocked = front_blocked or corner_blocked

            if now >= self.cooldown_until:
                if blocked:
                    if self.obstacle_seen_since is None:
                        self.obstacle_seen_since = now
                    elif (now - self.obstacle_seen_since) >= self.persistence:
                        self.get_logger().warn(
                            f"Trigger: blocked(front={front_blocked}, corner={corner_blocked}) "
                            f"dF={dF:.2f}, dL={dL:.2f}, dR={dR:.2f} -> AVOID"
                        )
                        self.mode = Mode.AVOID_START
                        return
                else:
                    self.obstacle_seen_since = None
            else:
                # During cooldown: emergency trigger if very close
                emergency = (dF < self.D_stop) or ((v_cmd_raw > self.corner_v_min) and (min(dL, dR) < self.D_stop))
                if emergency:
                    self.get_logger().warn("Emergency trigger during cooldown -> AVOID")
                    self.mode = Mode.AVOID_START
                    return

            # forward nav2 cmd with small side safety
            v_cmd, w_cmd = self.nav_side_nudge(v_cmd_raw, w_cmd_raw, dL, dR)
            self.publish_cmd(v_cmd, w_cmd, dt)
            return

        if self.mode == Mode.AVOID_START:
            self.stop_robot()
            self.cancel_nav_goal()

            self.decide_sides_at_trigger(dL, dR)
            self.avoid_started_at = now
            self.clear_seen_since = None
            self.obstacle_seen_since = None

            if self.odom_ready:
                self.arc_yaw0 = self.odom_yaw
            else:
                self.arc_yaw0 = 0.0

            self.get_logger().info(
                f"Avoidance started. obstacle_side={self.obstacle_side.name} detour_side={self.detour_side.name}"
            )
            self.mode = Mode.AVOID_ARC
            return

        if self.mode == Mode.AVOID_ARC:
            if (now - self.avoid_started_at) > self.detour_max_time:
                self.get_logger().warn("Detour timeout -> BACKUP")
                self.backup_end_at = now + self.backup_duration
                self.mode = Mode.AVOID_BACKUP
                return

            if self.odom_ready:
                dyaw = ang_wrap(self.odom_yaw - self.arc_yaw0)
                if abs(dyaw) > self.max_arc_yaw:
                    if dF > (self.D_stop + 0.08):
                        self.get_logger().warn(
                            f"Arc yaw cap hit ({math.degrees(abs(dyaw)):.0f}deg) -> FORWARD_PASS"
                        )
                        self.start_forward_pass()
                        return
                    self.get_logger().warn("Arc yaw cap hit but front still tight -> BACKUP")
                    self.backup_end_at = now + self.backup_duration
                    self.mode = Mode.AVOID_BACKUP
                    return

            v, w = self.compute_arc_cmd(dF, dL, dR)
            self.publish_cmd(v, w, dt)

            if self.should_exit_arc(dF, dL, dR):
                if self.clear_seen_since is None:
                    self.clear_seen_since = now
                elif (now - self.clear_seen_since) >= self.stable_time:
                    self.start_forward_pass()
                    return
            else:
                self.clear_seen_since = None

            return

        if self.mode == Mode.AVOID_BACKUP:
            if now >= self.backup_end_at:
                self.detour_side = Side.LEFT if self.detour_side == Side.RIGHT else Side.RIGHT
                self.avoid_started_at = now
                self.clear_seen_since = None
                if self.odom_ready:
                    self.arc_yaw0 = self.odom_yaw
                self.get_logger().info(f"Backup done. Switch detour_side -> {self.detour_side.name}")
                self.mode = Mode.AVOID_ARC
                return

            self.publish_cmd(-abs(self.v_backup), 0.0, dt)
            return

        if self.mode == Mode.AVOID_FORWARD_PASS:
            dx = self.odom_x - self.pass_start_x
            dy = self.odom_y - self.pass_start_y
            dist = math.sqrt(dx * dx + dy * dy)

            dObs = dL if self.obstacle_side == Side.LEFT else dR

            # If we get dangerously close again, return to ARC
            if dF < self.D_avoid or dObs < self.obstacle_min:
                self.get_logger().warn("Too close during forward pass -> ARC")
                self.clear_seen_since = None
                self.pass_clear_seen_since = None
                if self.odom_ready:
                    self.arc_yaw0 = self.odom_yaw
                self.mode = Mode.AVOID_ARC
                return

            # NEW: early exit if we've moved a little, and obstacle-side becomes clearly safe (stable)
            clear_thr = self.wall_target + self.pass_clear_margin
            early_clear = (dF > self.clear_front) and (dObs > clear_thr)

            if dist >= self.pass_min_distance and early_clear:
                if self.pass_clear_seen_since is None:
                    self.pass_clear_seen_since = now
                elif (now - self.pass_clear_seen_since) >= self.pass_clear_stable:
                    self.stop_robot()
                    self.mode = Mode.RESUME_GOAL
                    return
            else:
                self.pass_clear_seen_since = None

            # Original exit: fixed commit distance
            if dist >= self.commit_distance:
                self.stop_robot()
                self.mode = Mode.RESUME_GOAL
                return

            v, w = self.forward_pass_cmd(dL, dR)
            v, w = self.nav_side_nudge(v, w, dL, dR)
            self.publish_cmd(v, w, dt)
            return

        if self.mode == Mode.RESUME_GOAL:
            self.stop_robot()
            if self.original_goal is not None:
                self.get_logger().info("Resuming original goal with Nav2.")
                self.send_nav_goal(self.original_goal)
                self.cooldown_until = now + self.cool_down_sec
                self.mode = Mode.NAVIGATING
            else:
                self.mode = Mode.IDLE
            return

    def _handle_cliff(self, dt: float):
        now = self.now_sec()

        # Enter cliff mode
        if self.cliff_state == "NONE":
            self._pick_cliff_trigger_and_turn()
            self.cliff_state = "CLIFF_BRAKE"
            self.cliff_t0 = now
            self.cliff_clear_t0 = None

            # Optional but recommended: stop Nav2 goal so it doesn't keep pushing commands
            self.cancel_nav_goal()

        # State 1: Brake
        if self.cliff_state == "CLIFF_BRAKE":
            self.publish_cmd(0.0, 0.0, dt)
            if (now - self.cliff_t0) >= self.cliff_brake_s:
                self.cliff_state = "CLIFF_ESCAPE"
                self.cliff_t0 = now
            return

        # State 2: Escape (reverse then rotate)
        if self.cliff_state == "CLIFF_ESCAPE":
            t = now - self.cliff_t0

            # If rear cliff triggered, do NOT reverse into it: rotate first
            if self.cliff_trigger == "rear":
                if t < self.cliff_rotate_s:
                    self.publish_cmd(0.0, self.cliff_turn_sign * self.cliff_rotate_w, dt)
                    return
            else:
                if t < self.cliff_reverse_s:
                    self.publish_cmd(-self.cliff_reverse_v, 0.0, dt)
                    return
                elif t < (self.cliff_reverse_s + self.cliff_rotate_s):
                    self.publish_cmd(0.0, self.cliff_turn_sign * self.cliff_rotate_w, dt)
                    return

            # Require stable ground before exiting cliff mode
            if not self._cliff_active():
                if self.cliff_clear_t0 is None:
                    self.cliff_clear_t0 = now
                if (now - self.cliff_clear_t0) >= self.cliff_clear_stable_s:
                    self.cliff_state = "NONE"
                    self.cliff_trigger = None
                    self.cliff_clear_t0 = None

                    # After escape, go back to NAVIGATING (Nav2 will replan)
                    if self.original_goal is not None:
                        self.send_nav_goal(self.original_goal)
                        self.cooldown_until = self.now_sec() + self.cool_down_sec
                        self.mode = Mode.NAVIGATING
                    else:
                        self.mode = Mode.IDLE
                    return
            else:
                # Still on cliff -> hold stop
                self.cliff_clear_t0 = None
                self.publish_cmd(0.0, 0.0, dt)
                return




def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicDetourSupervisor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
