#!/usr/bin/env python3
import math
from functools import partial

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool


class IRCliffScanToBool(Node):
    """
    Converts downward IR ray LaserScan topics (1 sample) into debounced digital cliff signals.

    Input (LaserScan):
      - ranges[0] ~ small distance (e.g., 0.05..0.12) -> ground present
      - ranges[0] = inf or near range_max            -> no ground (cliff)

    Output (Bool):
      - True  = ground detected
      - False = cliff detected
    """

    def __init__(self):
        super().__init__("ir_scan_to_bool")

        # ----- Parameters -----
        self.declare_parameter("cliff_threshold_m", 0.15)  # if distance > this => cliff
        self.declare_parameter("bad_count_trigger", 3)     # consecutive "cliff" readings to trigger
        self.declare_parameter("good_count_clear", 5)      # consecutive "ground" readings to clear
        self.declare_parameter("treat_range_max_as_cliff", True)
        self.declare_parameter("publish_only_on_change", False)

        self.declare_parameter("front_scan_topic", "/ir_cliff_scan_front")
        self.declare_parameter("left_scan_topic",  "/ir_cliff_scan_left")
        self.declare_parameter("right_scan_topic", "/ir_cliff_scan_right")
        self.declare_parameter("rear_scan_topic",  "/ir_cliff_scan_rear")

        self.declare_parameter("front_bool_topic", "/ir/front")
        self.declare_parameter("left_bool_topic",  "/ir/left")
        self.declare_parameter("right_bool_topic", "/ir/right")
        self.declare_parameter("rear_bool_topic",  "/ir/rear")

        self.th = float(self.get_parameter("cliff_threshold_m").value)
        self.bad_trig = int(self.get_parameter("bad_count_trigger").value)
        self.good_clear = int(self.get_parameter("good_count_clear").value)
        self.treat_rmax = bool(self.get_parameter("treat_range_max_as_cliff").value)
        self.pub_on_change = bool(self.get_parameter("publish_only_on_change").value)

        # QoS suitable for sensors
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
        )

        # ----- Sensor map -----
        sensors = {
            "front": {
                "scan": str(self.get_parameter("front_scan_topic").value),
                "out":  str(self.get_parameter("front_bool_topic").value),
            },
            "left": {
                "scan": str(self.get_parameter("left_scan_topic").value),
                "out":  str(self.get_parameter("left_bool_topic").value),
            },
            "right": {
                "scan": str(self.get_parameter("right_scan_topic").value),
                "out":  str(self.get_parameter("right_bool_topic").value),
            },
            "rear": {
                "scan": str(self.get_parameter("rear_scan_topic").value),
                "out":  str(self.get_parameter("rear_bool_topic").value),
            },
        }

        # ----- State per sensor -----
        self.state_ground = {}   # current debounced output (True ground / False cliff)
        self.bad_count = {}
        self.good_count = {}
        self.pubs = {}

        for name, cfg in sensors.items():
            self.state_ground[name] = True  # assume safe at start
            self.bad_count[name] = 0
            self.good_count[name] = 0

            self.pubs[name] = self.create_publisher(Bool, cfg["out"], 10)

            self.create_subscription(
                LaserScan,
                cfg["scan"],
                partial(self.scan_cb, name=name),
                qos
            )

        self.get_logger().info(
            f"IR Scan→Bool running. threshold={self.th}m, bad_trigger={self.bad_trig}, good_clear={self.good_clear}"
        )

    def scan_cb(self, msg: LaserScan, name: str):
        # Get first range safely
        if not msg.ranges:
            d = float("inf")
        else:
            d = msg.ranges[0]

        # Decide: ground now?
        # cliff if:
        #  - not finite (inf/nan)
        #  - distance > threshold
        #  - optionally distance ~ range_max (some plugins clamp to max)
        is_cliff_now = False

        if not math.isfinite(d):
            is_cliff_now = True
        elif d > self.th:
            is_cliff_now = True
        elif self.treat_rmax and math.isfinite(msg.range_max) and d >= (msg.range_max - 1e-3):
            is_cliff_now = True

        ground_now = not is_cliff_now

        # Debounce / hysteresis
        if ground_now:
            self.good_count[name] += 1
            self.bad_count[name] = 0
        else:
            self.bad_count[name] += 1
            self.good_count[name] = 0

        prev = self.state_ground[name]
        new = prev

        # If currently ground, trigger cliff after N bad reads
        if prev is True and self.bad_count[name] >= self.bad_trig:
            new = False

        # If currently cliff, clear after N good reads
        if prev is False and self.good_count[name] >= self.good_clear:
            new = True

        self.state_ground[name] = new

        # Publish
        if (not self.pub_on_change) or (new != prev):
            out = Bool()
            out.data = new
            self.pubs[name].publish(out)


def main():
    rclpy.init()
    node = IRCliffScanToBool()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
