import os
import time

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    package_name = 'my_bot'

    world_arg = DeclareLaunchArgument(
        'world',
        default_value='empty.world',
        description='World file to load in Gazebo'
    )
    world_file = LaunchConfiguration('world')

    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory(package_name), 'launch', 'rsp.launch.py')
        ]),
        launch_arguments={'use_sim_time': 'true'}.items()
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ]),
        launch_arguments={
            'world': world_file,
            'extra_gazebo_args': '-s libgazebo_ros_init.so -s libgazebo_ros_factory.so'
        }.items()
    )

    # Unique gazebo model name every run (no conflicts)
    entity_name = f"my_bot_{int(time.time())}"

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', entity_name,
            '-x', '0', '-y', '0', '-z', '5',
            '-timeout', '60',
            '-spawn_service_timeout', '60',
        ],
        output='screen'
    )

    delayed_spawn = TimerAction(period=2.0, actions=[spawn_entity])

    return LaunchDescription([
        world_arg,
        rsp,
        gazebo,
        delayed_spawn,
    ])
